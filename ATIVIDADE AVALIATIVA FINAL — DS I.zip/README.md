# Controle de Estoque da Cantina

**Aluno(a):** Otavio da Silva Barbosa
**Turma:** Desenvolvimento de Sistemas 1
**Disciplina:** DSI-2A
**Tema escolhido:** Opção A — Controle de Estoque da Cantina

## Descrição do sistema

Sistema de console em Java que substitui o caderno de controle da cantina da escola.
Ele guarda os produtos (código, nome, preço unitário e quantidade em estoque), permite
registrar vendas — diminuindo o estoque — e calcula o valor total em estoque.
Os dados ficam apenas na memória (um `ArrayList<Produto>`) enquanto o programa está aberto.

## Como executar

Requisito: JDK 11 ou superior (testado com JDK 21).

**No IntelliJ IDEA**
1. `File > Open` e selecione a pasta do projeto.
2. Se a pasta `src` não estiver azul, clique com o botão direito nela e escolha
   `Mark Directory as > Sources Root`. Confirme o JDK em `File > Project Structure > Project SDK`.
3. Abra `Main.java` e clique no botão ▶ ao lado de `public static void main`.

**Pelo terminal** (na pasta do projeto)
```bash
mkdir out
javac -encoding UTF-8 -d out src/*.java
java -cp out Main
```
> No Windows, se os acentos aparecerem errados, rode antes `chcp 65001` ou use
> `java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp out Main`.

## Estrutura do projeto

```
src/Produto.java   -> classe da entidade (atributos privados, getters, cálculo do valor em estoque, retirada do estoque)
src/Main.java      -> menu, leitura de dados (Scanner), validações e operações
testes/            -> entradas (teste*.txt) e saídas obtidas (saida_*.txt) de cada teste
```

## Funcionalidades implementadas

| Opção | Funcionalidade |
|------|----------------|
| 1 | Cadastrar produto |
| 2 | Listar todos os produtos (mostra "ESGOTADO" quando a quantidade é 0) |
| 3 | Buscar produto pelo código |
| 4 | Registrar venda (diminui o estoque) |
| 5 | Exibir valor total do estoque (soma de preço × quantidade de todos os produtos) |
| 0 | Sair |

O menu se repete até o usuário escolher **0 - Sair**.

### Regras de validação aplicadas

- Código único: não permite repetir (o cadastro é cancelado com aviso). O código deve ser maior que zero.
- Nome não pode ser vazio (nem só espaços): o programa pergunta de novo.
- Preço deve ser maior que zero (aceita `5,50` ou `5.50`): o programa pergunta de novo.
- Quantidade em estoque não pode ser negativa (zero é permitido): o programa pergunta de novo.
- Quantidade vendida deve ser maior que zero.
- Não permite vender mais do que o estoque disponível.
- Código pesquisado inexistente: informa que o produto não foi encontrado.
- Uma venda recusada **não altera** o estoque.
- Texto digitado onde se espera número: o programa avisa e pede novamente (nada trava).

## Registro dos testes

Os testes foram executados com o programa compilado, alimentando o teclado com os arquivos
`testes/teste*.txt`. Para repetir qualquer teste:

```bash
java -cp out Main < testes/teste6_operacao_principal_venda.txt
```

A saída completa de cada execução está em `testes/saida_*.txt`.
Nos exemplos abaixo, "(produto)" significa: código `101`, nome `Suco`, preço `5,00`, quantidade `10`.

| # | Teste | Ação realizada e dados utilizados | Resultado esperado | Resultado obtido |
|---|-------|-----------------------------------|--------------------|------------------|
| 1 | Cadastro válido | Opção 1 com (produto); depois opção 2 | Produto armazenado e exibido na listagem | "Produto cadastrado com sucesso!" e a listagem mostrou `101 / Suco / R$ 5,00 / 10 / R$ 50,00`. ✅ |
| 2 | Código repetido | Cadastrar (produto); opção 1 de novo usando o código `101`; opção 2 | Segundo cadastro recusado; continua só um produto | "Cadastro cancelado: já existe um produto com o código 101." A listagem mostrou apenas um Suco. ✅ |
| 3 | Informação inválida | Opção 1 com código `-5`; depois código `102`, nome vazio e `"   "`, preço `0`, `-2` e `abc`, preço `7,50`, quantidade `-1` e `xyz`, quantidade `15` | Cada dado inválido recusado com mensagem; só o dado válido é aceito | Código `-5`: "Cadastro cancelado: o código deve ser um número maior que zero." Nome vazio: "Este campo não pode ficar vazio." (2×). Preço `0`/`-2`: "O preço deve ser maior que zero."; `abc`: "Digite um número". Qtd `-1`: "O estoque não pode ser negativo."; `xyz`: "Digite um número inteiro." Por fim cadastrou Pastel, R$ 7,50, 15 un. ✅ |
| 4 | Busca existente | Cadastrar (produto); opção 3 com código `101` | Mostrar os dados do produto | Exibiu código 101, Suco, R$ 5,00, estoque 10, valor em estoque R$ 50,00. ✅ |
| 5 | Busca inexistente | Cadastrar (produto); opção 3 com código `999`; opção 4 com código `999` | Informar que o código não existe | "Produto com código 999 não encontrado." (busca) e "... Venda não realizada." (venda). ✅ |
| 6 | Operação principal (venda) | Cadastrar (produto); opção 4: código `101`, quantidade `3`; opções 2 e 5 | Estoque 7; valor restante R$ 35,00 (exemplo do enunciado) | "Venda registrada com sucesso!", valor da venda R$ 15,00, "Estoque restante de Suco: 7 unidade(s)." Listagem: qtd 7 / R$ 35,00; total em estoque R$ 35,00. ✅ |
| 7 | Operação não permitida | Após vender 3 (estoque 7): vender `8`; vender `0`; vender `-2`; opções 2 e 5 | Todas as vendas recusadas; estoque continua 7 | "Venda recusada: estoque insuficiente. Disponível: 7 unidade(s). O estoque não foi alterado." e "Venda recusada: a quantidade vendida deve ser maior que zero." (2×). Listagem: qtd 7; total R$ 35,00. ✅ |
| 8 | Lista vazia | Sem cadastrar nada: opções 2, 3, 4 e 5 | Informar que não há produtos | "Nenhum produto cadastrado." nas quatro opções; o total exibiu R$ 0,00. ✅ |
| 9 | Opção inválida no menu | Digitar `9`, `abc`, `7` e Enter vazio; depois opção 2 e 0 | Avisar o erro e permitir nova escolha | "Opção inválida! Digite um número de 0 a 5." (4×); o menu voltou e as opções 2 e 0 funcionaram normalmente. ✅ |
| 10 | Extra: vários produtos e esgotado | Cadastrar Suco (R$ 5,00 × 10) e Pastel (`7.50` × 4); opção 5; vender os 4 pastéis; opções 2 e 5 | Total R$ 80,00; após a venda, Pastel esgotado e total R$ 50,00 | Total R$ 80,00 → venda de R$ 30,00 → listagem com Pastel qtd 0 "(ESGOTADO)" → total R$ 50,00. ✅ |

## Limitações

- Os dados não são salvos: ao fechar o programa, os produtos cadastrados são perdidos (permitido pelo enunciado).
- Não há opção de editar, excluir ou repor estoque de um produto já cadastrado (não era obrigatório).
- Os valores em dinheiro usam `double`, o que é suficiente para este exercício; em um sistema real
  seria melhor usar `BigDecimal` para evitar erros de arredondamento.
- Códigos são números inteiros.

## Uso de inteligência artificial

[REVISE ESTE TEXTO PARA DESCREVER, COM HONESTIDADE, COMO VOCÊ USOU — OU NÃO — FERRAMENTAS DE IA.]

Foi utilizada a ferramenta de IA **Claude (Anthropic)** para gerar a primeira versão do código-fonte,
dos arquivos de teste e deste README, a partir do enunciado da atividade. Depois disso, o código foi
lido, compilado, executado e testado por mim, e eu consigo explicar o funcionamento de cada parte.
